package views;

import java.awt.Point;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import punto_4_dib.grafica;
import static punto_4_dib.grafica.area_dib;
import static punto_4_dib.grafica.puntos_t;
import static punto_4_dib.grafica.resolver;
import static punto_4_dib.grafica.upd;

public class dibujo_View extends javax.swing.JFrame {

    /**
     * Creates new form dibujo_View
     */
    ArrayList<Point> puntos_exteriores;
    ArrayList<Point> puntos_interiores;
    int area;
    public dibujo_View() {
        initComponents();
    }
    public dibujo_View(ArrayList<Point> p, int res, ArrayList<Point> q) {
        initComponents();
        puntos_exteriores=p;
        puntos_interiores=q;
        area=res;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        tamaño = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        area_txt = new javax.swing.JLabel();
        area_txt2 = new javax.swing.JLabel();
        pares = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Generar.");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("Escriba el numero de puntos a generar.");

        pares.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paresActionPerformed(evt);
            }
        });

        jLabel2.setText("Puntos del grafico:");

        jButton2.setText("Salir.");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(area_txt2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 94, Short.MAX_VALUE)
                        .addComponent(area_txt, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(pares, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tamaño, javax.swing.GroupLayout.Alignment.LEADING))
                    .addComponent(jLabel2))
                .addContainerGap(282, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton2))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jButton2)
                .addGap(5, 5, 5)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(tamaño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(pares, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(area_txt2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(area_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        //
        upd(this.getGraphics());
        
        int n=0;
        try{
            int var=Integer.parseInt(tamaño.getText());
            if(var < 1 ||var > 100 ){
                JOptionPane.showMessageDialog(null, "Escriba un numero entre 1 y 100 ");
                return;
            }
            n=var;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Escriba un numero entero valido.");
            return;
        }
        puntos_exteriores=resolver(n);
        puntos_interiores=puntos_t();
        area=area_dib(puntos_exteriores);
        //
        for (int i = 0; i < puntos_exteriores.size(); i++){
            grafica.hacer_punto(this.getGraphics(), puntos_exteriores.get(i).x+175, ((puntos_exteriores.get(i).y+100)-400)*-1);
        }
        grafica.hacer_Linea(this.getGraphics(), puntos_exteriores.get(0).x+175, ((puntos_exteriores.get(0).y+100)-400)*-1, puntos_exteriores.get(puntos_exteriores.size()-1).x+175, ((puntos_exteriores.get(puntos_exteriores.size()-1).y+100)-400)*-1);
        for(int i=0;i<puntos_exteriores.size()-1;i++){
            grafica.hacer_Linea(this.getGraphics(), puntos_exteriores.get(i).x+175, ((puntos_exteriores.get(i).y+100)-400)*-1, puntos_exteriores.get(i+1).x+175, ((puntos_exteriores.get(i+1).y+100)-400)*-1);
        }
        for (int i = 0; i < puntos_interiores.size(); i++){
            grafica.hacer_punto(this.getGraphics(), puntos_interiores.get(i).x+175, ((puntos_interiores.get(i).y+100)-400)*-1);
        }
        grafica.hacer_Linea(this.getGraphics(), 175, 100, 175, 300);
        grafica.hacer_Linea(this.getGraphics(), 175, 300, 350, 300);
        //
        grafica.hacer_Str(this.getGraphics(), "0", 175, 315);
        grafica.hacer_Str(this.getGraphics(), "10", 185, 325);
        grafica.hacer_Str(this.getGraphics(), "20", 195, 315);
        grafica.hacer_Str(this.getGraphics(), "30", 205, 325);
        grafica.hacer_Str(this.getGraphics(), "40", 215, 315);
        grafica.hacer_Str(this.getGraphics(), "50", 225, 325);
        grafica.hacer_Str(this.getGraphics(), "60", 235, 315);
        grafica.hacer_Str(this.getGraphics(), "70", 245, 325);
        grafica.hacer_Str(this.getGraphics(), "80", 255, 315);
        
        grafica.hacer_Str(this.getGraphics(), "0", 160, 300);
        grafica.hacer_Str(this.getGraphics(), "10", 160, 290);
        grafica.hacer_Str(this.getGraphics(), "20", 160, 280);
        grafica.hacer_Str(this.getGraphics(), "30", 160, 270);
        grafica.hacer_Str(this.getGraphics(), "40", 160, 260);
        grafica.hacer_Str(this.getGraphics(), "50", 160, 250);
        grafica.hacer_Str(this.getGraphics(), "60", 160, 240);
        grafica.hacer_Str(this.getGraphics(), "70", 160, 230);
        grafica.hacer_Str(this.getGraphics(), "80", 160, 220);
        //
        area_txt.setText(""+area);
        area_txt2.setText("Area total de la figura: ");
        
        pares.removeAllItems();
        for (int i = 0; i < puntos_interiores.size(); i++){
            pares.addItem("(" + puntos_interiores.get(i).x + ", " + puntos_interiores.get(i).y + ")");
            System.out.println("(" + puntos_interiores.get(i).x + ", " + puntos_interiores.get(i).y + ")");
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void paresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paresActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paresActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(dibujo_View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(dibujo_View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(dibujo_View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(dibujo_View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new dibujo_View().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel area_txt;
    private javax.swing.JLabel area_txt2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JComboBox<String> pares;
    private javax.swing.JTextField tamaño;
    // End of variables declaration//GEN-END:variables
}
